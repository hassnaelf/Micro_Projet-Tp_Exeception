package SWING;



import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

//import net.proteanit.sql.DbUtils;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JScrollBar;

public class MedSwing extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_6;
	private JTextField textField_7;
	private JButton btnAjouter;
	private JButton btnModifier;
	private JButton btnSupprimer;
	private JButton btnAfficher;
	private JLabel label_1;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MedSwing  frame = new MedSwing ();
					frame.setUndecorated(true);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MedSwing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 829, 471);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 0, 340, 483);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Id du medecin");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 11));
		lblNewLabel.setBounds(10, 67, 83, 26);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(144, 65, 186, 32);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblM = new JLabel("version");
		lblM.setForeground(Color.RED);
		lblM.setFont(new Font("Arial Black", Font.BOLD, 11));
		lblM.setBounds(10, 134, 83, 26);
		panel.add(lblM);
		
		JLabel lblT = new JLabel("Titre");
		lblT.setForeground(Color.RED);
		lblT.setFont(new Font("Arial Black", Font.BOLD, 11));
		lblT.setBounds(10, 202, 136, 26);
		panel.add(lblT);
		
		
		
		JLabel lblN = new JLabel("Nom");
		lblN.setForeground(Color.RED);
		lblN.setFont(new Font("Arial Black", Font.BOLD, 11));
		lblN.setBounds(10, 261, 83, 26);
		panel.add(lblN);
		
		JLabel lblP = new JLabel("Prenom");
		lblP.setForeground(Color.RED);
		lblP.setFont(new Font("Arial Black", Font.BOLD, 11));
		lblP.setBounds(10, 326, 83, 26);
		panel.add(lblP);
		
		JLabel lb_close = new JLabel("X");
		lb_close.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				System.exit(0);
			}
		});
		lb_close.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 18));
		lb_close.setHorizontalAlignment(SwingConstants.CENTER);
		lb_close.setBounds(796, 0, 17, 27);
		lb_close.setForeground(Color.RED);
		contentPane.add(lb_close);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(144, 132, 186, 32);
		panel.add(textField_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(144, 200, 186, 32);
		panel.add(textField_3);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(144, 259, 186, 32);
		panel.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(144, 324, 186, 32);
		panel.add(textField_7);
		
		JLabel lblGestionDesMedecin = new JLabel("Gestion des Medecins");
		lblGestionDesMedecin.setForeground(Color.RED);
		lblGestionDesMedecin.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblGestionDesMedecin.setBounds(518, 33, 295, 75);
		contentPane.add(lblGestionDesMedecin);
		
		btnAjouter = new JButton("Ajouter");
		btnAjouter.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnAjouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_m�dicale","root","");
			Statement st=con.createStatement();
				String sql="insert into medecins values ("+Integer.parseInt(textField.getText())+","+Integer.parseInt(textField_1.getText())+",'"+textField_3.getText()+"','"+textField_6.getText()+"','"+textField_7.getText()+"')";
				textField.setText("");
				textField_1.setText("");
				textField_3.setText("");
				textField_6.setText("");
				textField_7.setText("");
				
			st.executeUpdate(sql);
				JOptionPane.showMessageDialog(null,"insertion avec succ�s!");
			}
			catch(Exception e){
				JOptionPane.showMessageDialog(null,e);
			}
		}});
		btnAjouter.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				btnAjouter.setBackground(Color.lightGray);
			}
			public void mouseExited(MouseEvent e) {
				btnAjouter.setBackground(Color.DARK_GRAY);
			}
		});
		btnAjouter.setBackground(new Color(64, 64, 64));
		btnAjouter.setForeground(new Color(255, 0, 0));
		btnAjouter.setBounds(350, 136, 104, 38);
		contentPane.add(btnAjouter);
		
		btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_m�dicale","root","");
			Statement st=con.createStatement();
			try{
					String sqll="select * from medecins where ID='"+textField.getText()+"'";
					ResultSet rs=st.executeQuery(sqll);
					if(rs.next())
					{
				String sql="UPDATE  medecins set VERSION="+Integer.parseInt(textField_1.getText())+",TITRE='"+textField_3.getText()+"',NOM='"+textField_6.getText()+"',PRENOM='"+textField_7.getText()+"' where ID="+Integer.parseInt(textField.getText())+"";
			st.executeUpdate(sql);
			JOptionPane.showMessageDialog(null,"modification avec succ�s!");
				textField.setText("");
				textField_1.setText("");
				textField_3.setText("");
				textField_6.setText("");
				
				textField_7.setText("");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "ce medecin n'existe pas!");
					}
}
			catch(NumberFormatException ne) {
				JOptionPane.showMessageDialog(null,ne);
			}
				
			}
			catch(Exception ec){
			JOptionPane.showMessageDialog(null,ec);
			}
			}
			
		});
		btnModifier.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				btnModifier.setBackground(Color.lightGray);
			}
			public void mouseExited(MouseEvent e) {
				btnModifier.setBackground(Color.DARK_GRAY);
			}
		});
		btnModifier.setForeground(Color.RED);
		btnModifier.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnModifier.setBackground(Color.DARK_GRAY);
		btnModifier.setBounds(464, 136, 104, 38);
		contentPane.add(btnModifier);
		
		btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_m�dicale","root","");
			Statement st=con.createStatement();
			try{
					String sqll="select * from medecins where ID='"+textField.getText()+"'";
					ResultSet rs=st.executeQuery(sqll);
					if(rs.next())
					{
	              String sql="delete from  medecins where  ID="+Integer.parseInt(textField.getText())+"";
			            st.executeUpdate(sql);
			            JOptionPane.showMessageDialog(null,"suppresion avec succ�s!");
				textField.setText("");
				textField_1.setText("");
			
				textField_3.setText("");
				
				textField_6.setText("");
				textField_7.setText("");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "ce Medecin n'existe pas!");
					}
			}
			catch(NumberFormatException ne) {
				JOptionPane.showMessageDialog(null,"probleme de conversion!");
			}
					
			}
			catch(Exception ec){
			JOptionPane.showMessageDialog(null,ec);
			}
			}
		});
		btnSupprimer.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				btnSupprimer.setBackground(Color.lightGray);
			}
			public void mouseExited(MouseEvent e) {
				btnSupprimer.setBackground(Color.DARK_GRAY);
			}
		});
		btnSupprimer.setForeground(Color.RED);
		btnSupprimer.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnSupprimer.setBackground(Color.DARK_GRAY);
		btnSupprimer.setBounds(576, 136, 104, 38);
		contentPane.add(btnSupprimer);
		
		btnAfficher = new JButton("Afficher");
		btnAfficher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Updatetable();
			}
		});
		btnAfficher.addMouseListener(new MouseAdapter() {
			public void mouseEntered(MouseEvent e) {
				btnAfficher.setBackground(Color.lightGray);
			}
			public void mouseExited(MouseEvent e) {
				btnAfficher.setBackground(Color.DARK_GRAY);
			}
		});
		btnAfficher.setForeground(Color.RED);
		btnAfficher.setFont(new Font("Arial Black", Font.BOLD, 11));
		btnAfficher.setBackground(Color.DARK_GRAY);
		btnAfficher.setBounds(690, 136, 104, 38);
		contentPane.add(btnAfficher);
		
		label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\MM.jpeg"));
		label_1.setBounds(350, 11, 149, 108);
		contentPane.add(label_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(350, 185, 453, 236);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		scrollPane.setColumnHeaderView(table);
	}
	public void Updatetable() {

		String sql="select ID,VERSION,TITRE,NOM,PRENOM from medecins";
		try {	
			Class.forName("com.mysql.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_m�dicale","root","");
			PreparedStatement prepared=con.prepareStatement(sql);
			ResultSet resultat=prepared.executeQuery(sql);
			table.setModel(DbUtils.resultSetToTableModel(resultat));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
