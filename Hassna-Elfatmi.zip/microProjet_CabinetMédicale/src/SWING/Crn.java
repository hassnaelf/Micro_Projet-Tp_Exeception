package SWING;

public class Crn {
	private int ID;
	private int VERSION;
	private int HDEBUT;
	private int MDEBUT;
	private int HFIN;
	private int MFIN;
	private int ID_MEDECIN;
	
	
	public Crn(int iD, int vERSION, int hDEBUT, int mDEBUT, int hFIN, int mFIN, int iD_MEDECIN) {
		super();
		ID = iD;
		VERSION = vERSION;
		HDEBUT = hDEBUT;
		MDEBUT = mDEBUT;
		HFIN = hFIN;
		MFIN = mFIN;
		ID_MEDECIN = iD_MEDECIN;
	}


	public int getID() {
		return ID;
	}


	public void setID(int iD) {
		ID = iD;
	}


	public int getVERSION() {
		return VERSION;
	}


	public void setVERSION(int vERSION) {
		VERSION = vERSION;
	}


	public int getHDEBUT() {
		return HDEBUT;
	}


	public void setHDEBUT(int hDEBUT) {
		HDEBUT = hDEBUT;
	}


	public int getMDEBUT() {
		return MDEBUT;
	}


	public void setMDEBUT(int mDEBUT) {
		MDEBUT = mDEBUT;
	}


	public int getHFIN() {
		return HFIN;
	}


	public void setHFIN(int hFIN) {
		HFIN = hFIN;
	}


	public int getMFIN() {
		return MFIN;
	}


	public void setMFIN(int mFIN) {
		MFIN = mFIN;
	}


	public int getID_MEDECIN() {
		return ID_MEDECIN;
	}


	public void setID_MEDECIN(int iD_MEDECIN) {
		ID_MEDECIN = iD_MEDECIN;
	}
	
	
	
	
	

}
