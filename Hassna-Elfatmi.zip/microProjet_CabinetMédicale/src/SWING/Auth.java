package SWING;



import java.awt.Button;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;


public class Auth extends JFrame {
	
	private Connection con;
	private Statement st;
	private ResultSet rs;

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	int xx,xy;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Auth frame = new Auth();
					frame.setUndecorated(true);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public Auth() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 829, 471);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, -11, 414, 598);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(-18, 97, 432, 311);
		panel.add(lblNewLabel_4);
		
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent arg0) {
				
				xx=arg0.getX();
				xy=arg0.getY();
				
			}
		});
		lblNewLabel_4.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent arg0) {
			int x=arg0.getXOnScreen();
			int y=arg0.getYOnScreen();
			Auth.this.setLocation(x - xx,y - xy);
				
			}
		});
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\cb.jpg"));
		lblNewLabel_4.setVerticalAlignment(SwingConstants.TOP);
		panel.add(lblNewLabel_4);
		
		
		Button button = new Button("se connecter");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_m�dicale","root","");
					st=con.createStatement();
					String sql="select * from logi where username='"+textField.getText()+"' and password='"+passwordField.getText().toString()+"'";
					rs=st.executeQuery(sql);
					if(rs.next())
					{
						Gestion gr=new Gestion();
						gr.setUndecorated(true);
						gr.setVisible(true);
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Nom d'utilisateur ou Mot de passe incorrecte!");
					}con.close();
				}
				catch(Exception e) {
					JOptionPane.showMessageDialog(null,e);
				}
			}
		});
		button.setBackground(Color.WHITE);
		button.setBackground(Color.RED);
		button.setBounds(458, 305, 303, 36);
		contentPane.add(button);
		
		
		textField = new JTextField();
		textField.setBounds(458, 111, 303, 36);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(458, 144, 303, 2);
		contentPane.add(separator);
		
		JLabel lblUsername = new JLabel("Nom d'utilisateur");
		lblUsername.setBounds(458, 72, 234, 14);
		contentPane.add(lblUsername);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(458, 259, 303, 2);
		contentPane.add(separator_2);
		
		JLabel lblPassword = new JLabel("Mot de passe");
		lblPassword.setBounds(458, 190, 173, 14);
		contentPane.add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(458, 225, 303, 36);
		contentPane.add(passwordField);
		
		JLabel lb_close = new JLabel("X");
		lb_close.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				System.exit(0);
			}
		});
		lb_close.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 18));
		lb_close.setHorizontalAlignment(SwingConstants.CENTER);
		lb_close.setBounds(796, 0, 17, 27);
		lb_close.setForeground(Color.RED);
		contentPane.add(lb_close);
	}
}
