package SWING;

import java.awt.EventQueue;

import javax.swing.JFrame;



import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import javax.swing.JComboBox;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Principal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal frame = new Principal();
					frame.setUndecorated(true);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the frame.
	 */
	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 820, 471);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("");
		label.setBackground(Color.LIGHT_GRAY);
		label.setForeground(Color.WHITE);
		label.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\cabiMed.jpg"));
		label.setBounds(0, 49, 978, 311);
		contentPane.add(label);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 11, 92, 39);
		contentPane.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(-19, 304, 845, 67);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 57, 858, 10);
		panel_1.add(panel);
		panel.setBackground(Color.RED);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("X");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setBounds(777, -2, 46, 40);
		contentPane.add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(SystemColor.inactiveCaptionText);
		panel_2.setBounds(0, 369, 826, 199);
		contentPane.add(panel_2);
		
		JButton btnNewButton = new JButton("Espase Administrateur");
		btnNewButton.setBounds(560, 21, 228, 43);
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 14));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Auth h=new Auth();
				h.setUndecorated(true);
				h.setVisible(true);
						
			}
		});
		panel_2.setLayout(null);
		
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setBackground(Color.RED);
		panel_2.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Quitter");
		btnNewButton_1.setBounds(322, 21, 228, 43);
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setFont(new Font("Calibri", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_1.setBackground(Color.RED);
		btnNewButton_1.setBackground(Color.RED);
		panel_2.add(btnNewButton_1);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(SystemColor.inactiveCaptionText);
		panel_3.setBounds(-9, -2, 845, 50);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblBienvennue = new JLabel("Gestion de Cabinet M�dicale");
		lblBienvennue.setBounds(59, 11, 371, 37);
		panel_3.add(lblBienvennue);
		lblBienvennue.setForeground(Color.WHITE);
		lblBienvennue.setFont(new Font("Brush Script MT", Font.ITALIC, 34));
	}
}
