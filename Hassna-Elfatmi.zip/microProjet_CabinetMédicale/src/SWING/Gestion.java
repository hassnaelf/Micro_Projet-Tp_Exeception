package SWING;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class Gestion extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						try {
							Gestion window = new Gestion();
							window.setUndecorated(true);
							window.setVisible(true);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}

			/**
			 * Create the application.
			 */
			public Gestion() {
				getContentPane().setBackground(Color.WHITE);
				initialize();
			}

			/**
			 * Initialize the contents of the frame.
			 */
			private void initialize() {
				//frame = new JFrame();
				this.setBounds(100, 100, 829, 471);
				this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				getContentPane().setLayout(null);
				
				JLabel label_1 = new JLabel("");
				label_1.setBounds(123, 153, 46, 14);
				getContentPane().add(label_1);
				
				JLabel label_2 = new JLabel("");
				label_2.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\2019-01-22 16.08.12.png"));
				label_2.setBounds(450, 198, 128, 98);
				getContentPane().add(label_2);
				
				JLabel label_3 = new JLabel("");
				label_3.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\cr.png"));
				label_3.setBounds(450, 315, 224, 132);
				getContentPane().add(label_3);
				
				JLabel label = new JLabel("");
				label.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\MM.png"));
				label.setBounds(95, 178, 211, 125);
				getContentPane().add(label);
				
				JLabel label_4 = new JLabel("");
				label_4.setIcon(new ImageIcon("C:\\Users\\Dell\\Desktop\\client.png"));
				label_4.setBounds(84, 309, 120, 123);
				getContentPane().add(label_4);
				
				JButton btnGrerLesClients = new JButton("Medecins");
				btnGrerLesClients.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						MedSwing cl=new MedSwing();
						cl.setUndecorated(true);
						cl.setVisible(true);
					}
				});
				btnGrerLesClients.addMouseListener(new MouseAdapter() {
					public void mouseEntered(MouseEvent e) {
						btnGrerLesClients.setBackground(Color.lightGray);
					}
					public void mouseExited(MouseEvent e) {
						btnGrerLesClients.setBackground(Color.DARK_GRAY);
					}
				});
				btnGrerLesClients.setFont(new Font("Arial Black", Font.BOLD, 12));
				btnGrerLesClients.setForeground(Color.RED);
				btnGrerLesClients.setBackground(Color.DARK_GRAY);
				btnGrerLesClients.setBounds(240, 211, 128, 56);
				getContentPane().add(btnGrerLesClients);
				
				JButton btnActivits = new JButton("Clients\u00E9s");
				btnActivits.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Client ac=new Client();
						ac.setUndecorated(true);
						ac.setVisible(true);
						
					}
				});
				btnActivits.addMouseListener(new MouseAdapter() {
					public void mouseEntered(MouseEvent e) {
						btnActivits.setBackground(Color.lightGray);
					}
					public void mouseExited(MouseEvent e) {
						btnActivits.setBackground(Color.DARK_GRAY);
					}
				});
				btnActivits.setForeground(Color.RED);
				btnActivits.setFont(new Font("Arial Black", Font.BOLD, 12));
				btnActivits.setBackground(Color.DARK_GRAY);
				btnActivits.setBounds(240, 351, 128, 56);
				getContentPane().add(btnActivits);
				
				JButton btnPlanning = new JButton("Rendez-vous");
				btnPlanning.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						RNV pl=new RNV();
						pl.setUndecorated(true);
						pl.setVisible(true);
					}
				});
				btnPlanning.addMouseListener(new MouseAdapter() {
					public void mouseEntered(MouseEvent e) {
						btnPlanning.setBackground(Color.lightGray);
					}
					public void mouseExited(MouseEvent e) {
						btnPlanning.setBackground(Color.DARK_GRAY);
					}
				});
				btnPlanning.setForeground(Color.RED);
				btnPlanning.setFont(new Font("Arial Black", Font.BOLD, 12));
				btnPlanning.setBackground(Color.DARK_GRAY);
				btnPlanning.setBounds(620, 211, 134, 56);
				getContentPane().add(btnPlanning);
				
				JButton btnCoachs = new JButton("Creneaux");
				btnCoachs.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Creneau cl=new Creneau();
						cl.setUndecorated(true);
						cl.setVisible(true);
					}
				});
				btnCoachs.addMouseListener(new MouseAdapter() {
					public void mouseEntered(MouseEvent e) {
						btnCoachs.setBackground(Color.lightGray);
					}
					public void mouseExited(MouseEvent e) {
						btnCoachs.setBackground(Color.DARK_GRAY);
					}
				});
				btnCoachs.setFont(new Font("Arial Black", Font.BOLD, 12));
				btnCoachs.setForeground(Color.RED);
				btnCoachs.setBackground(Color.DARK_GRAY);
				btnCoachs.setBounds(620, 351, 134, 56);
				getContentPane().add(btnCoachs);
				
				JPanel panel = new JPanel();
				panel.setBackground(Color.DARK_GRAY);
				panel.setBounds(0, 38, 830, 129);
				getContentPane().add(panel);
				
				JLabel label_7 = new JLabel("");
				label_7.setIcon(new ImageIcon("C:\\Users\\lenovo-\\Desktop\\new\\2019-01-22 16.57.14.png"));
				panel.add(label_7);
				
				JLabel label_6 = new JLabel("");
				label_6.setIcon(new ImageIcon("C:\\Users\\lenovo-\\Desktop\\new\\2019-01-22 16.56.57.png"));
				panel.add(label_6);
				
				JLabel lblEspaceDeGestion = new JLabel("Espace de gestion");
				panel.add(lblEspaceDeGestion);
				lblEspaceDeGestion.setForeground(Color.RED);
				lblEspaceDeGestion.setFont(new Font("AngsanaUPC", Font.BOLD, 74));
				lblEspaceDeGestion.setBackground(Color.DARK_GRAY);
				
				JLabel label_5 = new JLabel("");
				panel.add(label_5);
				JLabel lb_close = new JLabel("X");
				lb_close.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						
						System.exit(0);
					}
				});
				lb_close.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 18));
				lb_close.setHorizontalAlignment(SwingConstants.CENTER);
				lb_close.setBounds(784, 0, 29, 31);
				lb_close.setForeground(Color.RED);
				getContentPane().add(lb_close);
				
				JPanel panel_1 = new JPanel();
				panel_1.setBackground(Color.DARK_GRAY);
				panel_1.setBounds(0, 0, 830, 41);
				getContentPane().add(panel_1);
			}
		}
