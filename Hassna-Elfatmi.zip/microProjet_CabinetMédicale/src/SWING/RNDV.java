package SWING;

import java.sql.Date;

public class RNDV {
	private int ID;
	private  Date JOUR ;
	private int ID_CLIENT;
	private int ID_CRENEAU;
	
	public RNDV(int iD, Date jOUR, int iD_CLIENT, int iD_CRENEAU) {
		super();
		ID = iD;
		JOUR = jOUR;
		ID_CLIENT = iD_CLIENT;
		ID_CRENEAU = iD_CRENEAU;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public Date getJOUR() {
		return JOUR;
	}

	public void setJOUR(Date jOUR) {
		JOUR = jOUR;
	}

	public int getID_CLIENT() {
		return ID_CLIENT;
	}

	public void setID_CLIENT(int iD_CLIENT) {
		ID_CLIENT = iD_CLIENT;
	}

	public int getID_CRENEAU() {
		return ID_CRENEAU;
	}

	public void setID_CRENEAU(int iD_CRENEAU) {
		ID_CRENEAU = iD_CRENEAU;
	}
	
	
	
	

}
