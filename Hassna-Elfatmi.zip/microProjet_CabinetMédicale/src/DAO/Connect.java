package DAO;

import javax.swing.*;

import java.sql.*;

public class Connect {

	
	Connection conn=null;
	public static Connection ConnectDb() {

	try {
		Class.forName("com.mysql.jdbc.Driver");
	Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/cabinet_m�dicale","root","");
	System.out.println("aa ");
	return conn;

					}catch(Exception e){

JOptionPane.showMessageDialog(null,e);
	return null;
	}
	
	}
	
	
	}

