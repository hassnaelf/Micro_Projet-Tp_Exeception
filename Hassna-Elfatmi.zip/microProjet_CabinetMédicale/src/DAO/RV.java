
package DAO;

	import java.util.List;

	import SWING.RNDV;

	public interface RV{
		public void addRV(RNDV R);
		public void uppdateRV(RNDV R);
		public void deleteeRV(RNDV R);
		public RNDV getRV(int ID);
		public List<RNDV>getRV();


	}



