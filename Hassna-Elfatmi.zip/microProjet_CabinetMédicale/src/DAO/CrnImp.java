package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import SWING.Cli;
import SWING.Crn;

public class CrnImp implements Creneau{

	@Override
	public void addCreneau(Crn c) {
		 Connection con = Connect.ConnectDb();
			try {
				String query="INSERT INTO creneaux (ID,VERSION,HDEBUT,HFIN,MFIN,ID_MEDECIN) VALUES('"+c.getID()+"','"+c.getVERSION()+"','"+c.getHDEBUT()+"','"+c.getMDEBUT()+"','"+c.getHFIN()+"','"+c.getMFIN()+"','"+c.getID_MEDECIN()+"')";
					PreparedStatement pr=con.prepareStatement(query);
					pr.execute();	
		JOptionPane.showMessageDialog(null,"insertion avec succ�s!");
	}catch (Exception e1) {
		e1.printStackTrace();
	}
		
	}

	@Override
	public void uppdateCreneau(Crn c) {
		int M1=c.getID();
		int M2=c.getVERSION();
		int M3=c.getHDEBUT();
		int M4=c.getMDEBUT();
		int M5=c.getHFIN();
		int M6=c.getMFIN();
		int M7=c.getID_MEDECIN();
		Connection con = Connect.ConnectDb();

		String sql="update creneaux set VERSION='"+M2+"',HDEBUT='"+M3+"',MDEBUT='"+M4+"',HDFIN='"+M5+"',MDFIN='"+M6+"',ID_MEDECIN='"+M7+"' where ID='"+M1+"'";
		try {
			PreparedStatement prepared=con.prepareStatement(sql);
			if(prepared.execute()) {
				JOptionPane.showMessageDialog(null,"modification avec succ�s!");
				
				
				
					}
					else
					{
						JOptionPane.showMessageDialog(null, "ce creneau n'existe pas!");
					}		}catch(Exception e1) {
			e1.printStackTrace();
		}
		
	}
	public void DeleteCreneau(Crn c) {
		
		int M1=c.getID();
		Connection con = Connect.ConnectDb();
		  String sql="delete from  creneaux where  ID="+M1+"";
			try {
				PreparedStatement prepared=con.prepareStatement(sql);
				if(prepared.execute()) {

					  JOptionPane.showMessageDialog(null,"suppresion avec succ�s!");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "ce creneau n'existe pas!");
				}
			}catch(Exception e1) {
				e1.printStackTrace();
			}
		
	}
	

	

	@Override
	public Crn getCreneu(int ID) {
		Connection con = Connect.ConnectDb();
		String sql="select * from creneaux where ID=?";
		Crn m=null;
		try {
			
			PreparedStatement prepared=con.prepareStatement(sql);
			prepared.setInt(1,ID);
			ResultSet resultat=prepared.executeQuery();
			while(resultat.next())
			{
				 m=new Crn(resultat.getInt(1),resultat.getInt(2),resultat.getInt(3),resultat.getInt(4),resultat.getInt(5),resultat.getInt(6),resultat.getInt(7));
			
			}
			

		}catch(Exception e4) {
		
			System.out.println(e4);
			

	}
		return m;
	}

	@Override
	public List<Crn> getCreneau() {
		Connection con = Connect.ConnectDb();
		 List <Crn>mm=new ArrayList<>();
		try {
			String sql ="Select * from creneaux";
			
			PreparedStatement prepared=con.prepareStatement(sql);
			ResultSet resultat=prepared.executeQuery(sql);
			while(resultat.next())
			{
				Crn m=new Crn(resultat.getInt(1),resultat.getInt(2),resultat.getInt(3),resultat.getInt(4),resultat.getInt(5),resultat.getInt(6),resultat.getInt(7));
				mm.add(m);
			}
			
				}catch(Exception e) {
					System.out.println(e);
				
				}
		return mm;
	}

	
	
	

}
