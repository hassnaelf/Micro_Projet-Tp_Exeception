package DAO;

import java.util.List;

import SWING.Cli;
import SWING.Crn;

public interface Creneau {
	public void addCreneau(Crn c);
	public void uppdateCreneau(Crn c);
	public void DeleteCreneau(Crn c);
	Crn getCreneu(int ID);
	List<Crn>getCreneau();

}
