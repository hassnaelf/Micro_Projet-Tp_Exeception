package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;



import SWING.Med;

public class MedecinsImp implements Medecins{
	
	public void addMedecins(Med M) {
		 Connection con = Connect.ConnectDb();
		try {
			String query="INSERT INTO medecins (ID,VERSION,TITRE,NOM,PRENOM) VALUES('"+M.getID()+"','"+M.getVERSION()
			
		+"','"+M.getTITRE()+"','"+M.getNOM()+"','"+M.getPRENOM()+"')";
				PreparedStatement pr=con.prepareStatement(query);
				pr.execute();

			
				JOptionPane.showMessageDialog(null,"insertion avec succ�s!");
}catch (Exception e1) {
	e1.printStackTrace();
}
		
	}

	@Override
	public void uppdateMedecins(Med M) {
		int M1=M.getID();
		int M2=M.getVERSION();
		String M3=M.getTITRE();
		String M4=M.getNOM();
		String M5=M.getPRENOM();
		Connection con = Connect.ConnectDb();

		String sql="update medecins set VERSION='"+M2+"',TITRE='"+M3+"',NOM='"+M4+"',PRENOM='"+M5+"' where ID='"+M1+"'";
		try {
			PreparedStatement prepared=con.prepareStatement(sql);
			if(prepared.execute()) {
				JOptionPane.showMessageDialog(null,"modification avec succ�s!");
				
				
				
					}
					else
					{
						JOptionPane.showMessageDialog(null, "ce medecin n'existe pas!");
					}
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	
		
	}
	public void DeleteMedecins(Med M) {
		int M1=M.getID();
		Connection con = Connect.ConnectDb();
		  String sql="delete from  medecins where  ID="+M1+"";
			try {
				PreparedStatement prepared=con.prepareStatement(sql);
				if(prepared.execute()) {

					  JOptionPane.showMessageDialog(null,"suppresion avec succ�s!");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "ce medecin n'existe pas!");
				}
			}catch(Exception e1) {
				e1.printStackTrace();
			}
	}

	@Override
	public Med getMedecins(int ID) {
		Connection con = Connect.ConnectDb();
		String sql="select * from medecins where ID=?";
		Med m=null;
		try {
			
			PreparedStatement prepared=con.prepareStatement(sql);
			prepared.setInt(1,ID);
			ResultSet resultat=prepared.executeQuery();
			while(resultat.next())
			{
				 m=new Med(resultat.getInt(1),resultat.getInt(2),resultat.getString(3),resultat.getString(4),resultat.getString(5));
			
			}
			

		}catch(Exception e4) {
		
			System.out.println(e4);
			

	}
		return m;
		
	}

	@Override
	public List<Med> getMedecins() {
		
		Connection con = Connect.ConnectDb();
		 List <Med>mm=new ArrayList<>();
		try {
			String sql ="Select * from medecins";
			
			PreparedStatement prepared=con.prepareStatement(sql);
			ResultSet resultat=prepared.executeQuery(sql);
			while(resultat.next())
			{
				Med m=new Med(resultat.getInt(1),resultat.getInt(2),resultat.getString(3),resultat.getString(4),resultat.getString(5));
				mm.add(m);
			}
			
				}catch(Exception e) {
					System.out.println(e);
				
				}
		return mm;
	}

}
