package DAO;
import java.util.*;

import SWING.Med;

public interface Medecins {
	public void addMedecins(Med M);
	public void uppdateMedecins(Med M);
	public void DeleteMedecins(Med M);
	Med getMedecins(int ID);
	List<Med>getMedecins();

}
