package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import SWING.Cli;
import SWING.RNDV;

public class RVImpl implements RV{

	@Override
	public void addRV(RNDV R) {
		 Connection con = Connect.ConnectDb();
			try {
				String query="INSERT INTO rv (ID,JOUR,ID_CLIENT,ID_CRENEAU) VALUES('"+R.getID()+"','"+R.getJOUR()+"','"+R.getID_CLIENT()+"','"+R. getID_CRENEAU()+"')";
					PreparedStatement pr=con.prepareStatement(query);
					pr.execute();

				
		JOptionPane.showMessageDialog(null,"insersion avec succ�s");
	}catch (Exception e1) {
		e1.printStackTrace();
	}
		
	}

	@Override
	public void uppdateRV(RNDV R) {
		int M1=R.getID();
		Date M2=R.getJOUR();
		int M3=R.getID_CLIENT();
		int M4=R.getID_CRENEAU();
		
		Connection con = Connect.ConnectDb();

		String sql="update rv set JOUR='"+M2+"',ID_CLIENT='"+M3+"',ID_CRENEAU='"+M4+"'where ID='"+M1+"'";
		try {
			PreparedStatement prepared=con.prepareStatement(sql);
			if(prepared.execute()) {
				JOptionPane.showMessageDialog(null,"modification avec succ�s!");
				
				
				
					}
					else
					{
						JOptionPane.showMessageDialog(null, "ce rendez-vous n'existe pas!");}
		}catch(Exception e1) {
			e1.printStackTrace();
		}
		
	}
	public void deleteeRV(RNDV R) {
		int M1=R.getID();
		Connection con = Connect.ConnectDb();
		  String sql="delete from  rv where  ID="+M1+"";
			try {
				PreparedStatement prepared=con.prepareStatement(sql);
				if(prepared.execute()) {

					  JOptionPane.showMessageDialog(null,"suppresion avec succ�s!");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "ce rendez-vous n'existe pas!");
				}
			}catch(Exception e1) {
				e1.printStackTrace();
			}
		
	}

	@Override
	public RNDV getRV(int ID) {
		Connection con = Connect.ConnectDb();
		String sql="select * from rv where ID=?";
		RNDV m=null;
		try {
			
			PreparedStatement prepared=con.prepareStatement(sql);
			prepared.setInt(1,ID);
			ResultSet resultat=prepared.executeQuery();
			while(resultat.next())
			{
				 m=new RNDV(resultat.getInt(1),resultat.getDate(2),resultat.getInt(3),resultat.getInt(4));
			
			}
			

		}catch(Exception e4) {
		
			System.out.println(e4);
			

	}
		return m;
	}

	@Override
	public List<RNDV> getRV() {
		Connection con = Connect.ConnectDb();
		 List <RNDV>mm=new ArrayList<>();
		try {
			String sql ="Select * from rv";
			
			PreparedStatement prepared=con.prepareStatement(sql);
			ResultSet resultat=prepared.executeQuery(sql);
			while(resultat.next())
			{
				RNDV m=new RNDV(resultat.getInt(1),resultat.getDate(2),resultat.getInt(3),resultat.getInt(4));
				mm.add(m);
			}
			
				}catch(Exception e) {
					System.out.println(e);
				
				}
		return mm;
	}
	


}
