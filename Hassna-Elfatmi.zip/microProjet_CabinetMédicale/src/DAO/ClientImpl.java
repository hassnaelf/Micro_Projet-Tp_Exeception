package DAO;


	import java.sql.Connection;
	import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
	import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

	import javax.swing.JOptionPane;

import SWING.Cli;
import SWING.Med;

	
	public class ClientImpl implements Client{
		public void addCliens(Cli c) {
			 Connection con = Connect.ConnectDb();
			try {
				String query="INSERT INTO client (ID,VERSION,TITRE,NOM,PRENOM) VALUES('"+c.getID()+"','"+c.getVERSION()+"','"+c.getTITRE()+"','"+c.getNOM()+"','"+c.getPRENOM()+"')";
					PreparedStatement pr=con.prepareStatement(query);
					pr.execute();	
					JOptionPane.showMessageDialog(null,"insertion avec succ�s!");
	}catch (Exception e1) {
		e1.printStackTrace();
	}
			
		}

		

		@Override
		public void uppdateClients(Cli c) {
			int M1=c.getID();
			int M2=c.getVERSION();
			String M3=c.getTITRE();
			String M4=c.getNOM();
			String M5=c.getPRENOM();
			Connection con = Connect.ConnectDb();
			
			String sql="update client set VERSION='"+M2+"',TITRE='"+M3+"',NOM='"+M4+"',PRENOM='"+M5+"' where ID='"+M1+"'";
			try {
				PreparedStatement prepared=con.prepareStatement(sql);
				
if(prepared.execute()) {
				JOptionPane.showMessageDialog(null,"modification avec succ�s!");
				
				
				
					}
					else
					{
						JOptionPane.showMessageDialog(null, "ce client n'existe pas!");
					}
			}catch(Exception e1) {
				e1.printStackTrace();
			}
			
		}
		public void DeleteClients(Cli c) {
			int M1=c.getID();
			Connection con = Connect.ConnectDb();
			  String sql="delete from  medecins where  ID="+M1+"";
				try {
					PreparedStatement prepared=con.prepareStatement(sql);
					if(prepared.execute()) {

						  JOptionPane.showMessageDialog(null,"suppresion avec succ�s!");
					}
					else
					{
						JOptionPane.showMessageDialog(null, "ce client n'existe pas!");
					}
				}catch(Exception e1) {
					e1.printStackTrace();
				}
			
		}
		@Override
		public Cli getClients(int ID) {
			Connection con = Connect.ConnectDb();
			String sql="select * from client where ID=?";
			Cli m=null;
			try {
				
				PreparedStatement prepared=con.prepareStatement(sql);
				prepared.setInt(1,ID);
				ResultSet resultat=prepared.executeQuery();
				while(resultat.next())
				{
					 m=new Cli(resultat.getInt(1),resultat.getInt(2),resultat.getString(3),resultat.getString(4),resultat.getString(5));
				
				}
				

			}catch(Exception e4) {
			
				System.out.println(e4);
				

		}
			return m;
		}

		@Override
		public List<Cli> getClients() {
			Connection con = Connect.ConnectDb();
			 List <Cli>mm=new ArrayList<>();
			try {
				String sql ="Select * from client";
				
				PreparedStatement prepared=con.prepareStatement(sql);
				ResultSet resultat=prepared.executeQuery(sql);
				while(resultat.next())
				{
					Cli m=new Cli(resultat.getInt(1),resultat.getInt(2),resultat.getString(3),resultat.getString(4),resultat.getString(5));
					mm.add(m);
				}
				
					}catch(Exception e) {
						System.out.println(e);
					
					}
			return mm;
		}
		}

	

