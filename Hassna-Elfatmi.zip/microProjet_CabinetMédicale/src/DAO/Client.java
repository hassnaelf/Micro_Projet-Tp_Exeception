package DAO;

import java.util.List;

import SWING.Cli;

public interface Client {
	public void addCliens(Cli c);
	public void uppdateClients(Cli c);
	public void DeleteClients(Cli c);
	public Cli getClients(int ID);
	public List<Cli>getClients();

}
